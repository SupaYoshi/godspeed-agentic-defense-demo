# Godspeed IQ Grounding Overview

Godspeed Agentic Defense turns an urgent cyber scenario into a governed defense mission.

The mission flow is:

1. Classify the scenario.
2. Separate facts, assumptions and unknowns.
3. Select specialist defense agents.
4. Run a premortem before recommending action.
5. Plan lab-first validation.
6. Block risky production actions behind human approval gates.
7. Produce an evidence package for a security incident owner.

The knowledge layer should ground answers in these principles:

- Planning is allowed in the local sandbox.
- Production remediation is not allowed in the local sandbox.
- Customer data, tenant secrets and production tool connections are out of scope.
- Foundry IQ live tenant proof is approval-gated and tenant-proof pending.
- A mission package is not proof that patching, containment, credential reset or external communication occurred.

Expected evidence includes selected agents, approval gates, action owners, unresolved unknowns, source references and screenshot-ready proof points.
